
import React from 'react';
import { Player } from '../types';

interface PlayerCardProps {
  player: Player;
  isUser: boolean;
  onVote?: (id: string) => void;
  canVote?: boolean;
  isVotedByUser?: boolean;
}

const PlayerCard: React.FC<PlayerCardProps> = ({ player, isUser, onVote, canVote, isVotedByUser }) => {
  return (
    <div 
      className={`relative group p-2 sm:p-3 rounded-2xl transition-all duration-500 reveal-node perspective-1000 ${
        player.isAlive ? 'glass-panel hover:scale-110 hover:-translate-y-2 active:scale-95' : 'bg-black/40 grayscale opacity-40 scale-90 shake-death'
      } ${canVote && player.isAlive && !isUser ? 'cursor-pointer' : ''} ${
        isVotedByUser ? 'ring-4 ring-red-600 shadow-[0_0_30px_rgba(220,38,38,0.6)] border-red-500 z-30' : ''
      }`}
      onClick={() => canVote && !isUser && player.isAlive && onVote?.(player.id)}
    >
      <div className="flex flex-col items-center gap-1 sm:gap-2 transition-transform duration-500 group-hover:rotate-y-12">
        <div className={`w-14 h-14 sm:w-20 sm:h-20 rounded-full overflow-hidden border-2 bg-zinc-900/50 flex items-center justify-center transition-all duration-700 ${isVotedByUser ? 'border-red-600 scale-110 heartbeat' : 'border-zinc-800'}`}>
           <img 
            src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${player.name}`} 
            alt={player.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="text-center w-full">
          <p className={`font-bold text-[10px] sm:text-xs heading-font truncate max-w-full tracking-wide transition-colors ${isVotedByUser ? 'text-red-500' : 'text-zinc-100'}`}>
            {player.name}
          </p>
          {!player.isAlive ? (
            <div className="mt-1 animate-pulse">
              <span className="text-red-600 text-[8px] font-black uppercase tracking-widest block">Condannato</span>
            </div>
          ) : (
            isVotedByUser && <span className="text-red-400 text-[8px] font-bold uppercase tracking-tighter">Accusato</span>
          )}
        </div>
      </div>
      
      {canVote && player.isAlive && !isUser && !isVotedByUser && (
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 bg-red-950/20 rounded-2xl">
           <div className="bg-red-600 text-white text-[8px] sm:text-[10px] px-3 py-1 rounded-full font-black uppercase shadow-lg tracking-widest translate-y-2 group-hover:translate-y-0 transition-transform">
             Accusa
           </div>
        </div>
      )}
    </div>
  );
};

export default PlayerCard;
