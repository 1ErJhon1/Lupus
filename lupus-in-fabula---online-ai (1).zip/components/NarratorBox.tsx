
import React from 'react';

interface NarratorBoxProps {
  message: string;
  title?: string;
}

const NarratorBox: React.FC<NarratorBoxProps> = ({ message, title = "Il Narratore" }) => {
  return (
    <div className="w-full max-w-2xl mx-auto mb-6 sm:mb-8 reveal-node">
      <div className="glass-panel rounded-3xl p-5 sm:p-6 border-l-8 border-l-red-900 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden relative group">
        <div className="absolute -top-4 -right-4 opacity-5 text-7xl transition-transform duration-1000 group-hover:rotate-12">🩸</div>
        <h3 className="heading-font text-red-700 text-xs sm:text-sm mb-2 tracking-[0.4em] uppercase font-black">{title}</h3>
        <div className="relative">
          <p className="text-zinc-100 text-sm sm:text-lg italic leading-relaxed font-medium animate-in fade-in slide-in-from-bottom-2 duration-1000">
            "{message}"
          </p>
          <div className="w-full h-px bg-gradient-to-r from-red-900/50 to-transparent mt-3"></div>
        </div>
      </div>
    </div>
  );
};

export default NarratorBox;
