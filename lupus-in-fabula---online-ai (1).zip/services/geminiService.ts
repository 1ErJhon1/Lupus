
import { GoogleGenAI, Type } from "@google/genai";
import { GameState, Role, Player } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGameNarrative = async (state: GameState, action: string) => {
  const model = 'gemini-3-flash-preview';
  
  const prompt = `
    Sei il Narratore oscuro di Lupus in Fabula. 
    Ultimo evento: ${action}
    Giocatori vivi: ${state.players.filter(p => p.isAlive).map(p => p.name).join(', ')}
    
    Genera un commento in italiano brevissimo (max 12 parole).
    Stile: macabro, poetico, lapidario.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    return "L'oscurità attende...";
  }
};

export const getAIPlayerDecisions = async (state: GameState) => {
  const model = 'gemini-3-flash-preview';
  const alivePlayers = state.players.filter(p => p.isAlive);
  const aiPlayers = alivePlayers.filter(p => p.isAI);
  
  const prompt = `
    Sei il motore di gioco. Decidi le azioni degli AI (Lupi, Veggente, ecc.).
    Vivi: ${JSON.stringify(alivePlayers)}
    AI: ${JSON.stringify(aiPlayers)}
    
    Restituisci JSON con 'votes' (array {voterId, targetId}) e 'dialogue' (max 8 parole).
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            votes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  voterId: { type: Type.STRING },
                  targetId: { type: Type.STRING }
                },
                required: ["voterId", "targetId"]
              }
            },
            dialogue: { type: Type.STRING }
          },
          required: ["votes", "dialogue"]
        }
      }
    });

    const parsed = JSON.parse(response.text);
    const votesMap: Record<string, string> = {};
    if (Array.isArray(parsed.votes)) {
      parsed.votes.forEach((vote: { voterId: string, targetId: string }) => {
        votesMap[vote.voterId] = vote.targetId;
      });
    }
    return { votes: votesMap, dialogue: parsed.dialogue };
  } catch (error) {
    return { votes: {}, dialogue: "La nebbia sale." };
  }
};
